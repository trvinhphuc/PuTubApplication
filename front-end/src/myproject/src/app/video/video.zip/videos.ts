export class Video{
    id: number;
    name: string;
}