import { Video } from './videos';

export const VIDEOS: Video[] = [
    { id: 1, name: 'videoname1' },
    { id: 2, name: 'videoname2' },
    { id: 3, name: 'videoname3' },
    { id: 4, name: 'videoname4' },
    { id: 5, name: 'videoname5' },
    { id: 6, name: 'videoname6' },
];