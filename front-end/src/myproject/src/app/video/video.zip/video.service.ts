import { Injectable } from '@angular/core';
import { Video } from './videos';
import { VIDEOS } from './mock_video';

@Injectable()
export class Video_Service {
  getVideos(): Promise<Video[]> {
    //console.log(VIDEOS);
    return Promise.resolve(VIDEOS);
  }
  getVideo(id: number | string) {
    return Promise.resolve(VIDEOS)
      .then(videos => videos.find(video => video.id === +id));
  }
}