import { Injectable } from '@angular/core';
import { User } from './user';
import { USERS } from './mock_user';
@Injectable()
export class User_Service {
  getUsers(): Promise<User[]> {
    return Promise.resolve(USERS);
  }
}