package webservice.server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DbConnection {
	private final String url = "jdbc:sqlserver://localhost\\\\mssqlserver2:1433; databaseName=PuTub_DB;";
	private final String username = "sa";
	private final String password = "12345";
	Connection connection = null;

	public DbConnection() {
		try {
			
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		} catch (ClassNotFoundException e) {
			System.out.println("ERROR: Unable to load SQLServer JDBC Driver");
			e.printStackTrace();
			return;
		}

		try {
			connection = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			System.out.println("ERROR: Unable to establish a connection with this database");
			e.printStackTrace();
			return;
		}
	}

	public Connection getConnection() {
		try {
			connection = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			System.out.println("ERROR: Unable to establish a connection with this database");
			e.printStackTrace();
			return null;
		}
		return connection;
	}

	public void closeConnection() {
		try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
